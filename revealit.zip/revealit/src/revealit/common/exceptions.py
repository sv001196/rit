class AwsResourceException(Exception):
    def __init__(self,message):
        super(AwsResourceException,self).__init__(message)

class DynamoDbPutItemFailedException(Exception):
    def __init__(self,message):
        super(DynamoDbPutItemFailedException,self).__init__(message)

class EnvironmentException(Exception):
    def __init__(self,message):
        super(EnvironmentException,self).__init__(message)

class InvalidArgumentException(Exception):
    def __init__(self,message):
        super(InvalidArgumentException,self).__init__(message)

class InvalidInputException(Exception):
    def __init__(self,message):
        super(InvalidInputException,self).__init__(message)

class GenericEventValidationException(Exception):
    ERR_MSG_EVENT_VALIDATION_EXCP = 'Exception caught in event validation'

    def __init__(self,message):
        super(GenericEventValidationException, self).__init__(GenericEventValidationException.ERR_MSG_EVENT_VALIDATION_EXCP + ' ' + message)

class InvalidHttpRequestException(Exception):
    def __init__(self, message):
        # Call the base class constructor with the parameters it needs
        super(InvalidHttpRequestException, self).__init__(message)

class BatchExecutionException(Exception):
    def __init__(self, message):
        # Call the base class constructor with the parameters it needs
        super(BatchExecutionException, self).__init__(message)

class ExecutionFinishedException(Exception):
    def __init__(self,message):
        super(ExecutionFinishedException,self).__init__(message)

class CrawlerCreationException(Exception):
    def __init__(self, message, error_code):
        super(CrawlerCreationException,self).__init__(message)
        self.error_code = error_code

class CrawlerRunException(Exception):
    def __init__(self, message, error_code):
        super(CrawlerRunException,self).__init__(message)
        self.error_code = error_code