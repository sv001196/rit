import os
from common.exceptions import EnvironmentException

class EnvironmentType:
    LOCAL_HOST = 'LOCAL_HOST'
    CLOUD = 'CLOUD'

class EnvConfig:
    LOCAL_ENVIRONMENT = "LOCAL_ENVIRONMENT"

    @staticmethod
    def _get_env_variable(key):
        return os.environ[key] if key in os.environ else None

    @staticmethod
    def get_log_level(level):
        result = EnvConfig._get_env_variable(level)
        #result = '0' if result is None else str(result)
        result = '1'
        return result

    @staticmethod
    def environment_type():
        value = EnvConfig._get_env_variable(EnvConfig.LOCAL_ENVIRONMENT)
        result = EnvironmentType.CLOUD if value is None else value  # EnvironmentType.LOCAL_HOST
        return result

    @staticmethod
    def to_json():
        result = os.environ
        return result

    @staticmethod
    def get_redis_config():
        redis_host = 'localhost'
        redis_port = '6379'
        redis_pwd = None

        if EnvConfig.environment_type() == EnvConfig.LOCAL_ENVIRONMENT:
            return redis_host, redis_port
        else:
            redis_pwd = ''
            return redis_host, redis_port, redis_pwd

    @staticmethod
    def get_mongo_host():
        return 'localhost'

    @staticmethod
    def get_mongo_port():
        return '27017'

    @staticmethod
    def get_mongo_config():
        mongo_host = EnvConfig.get_mongo_host()
        mongo_port = EnvConfig.get_mongo_port()
        return 'mongodb://{}:{}/'.format(mongo_host, mongo_port)

