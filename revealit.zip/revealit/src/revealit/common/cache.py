import traceback
import ast
import redis
from common.log import Log
from common.env_config import EnvConfig
from common.exceptions import InvalidArgumentException


class RedisCache:
    def __init__(self):
        redis_host, redis_port, redis_password = EnvConfig.get_redis_config()

        self._redis_conn = None

        try:
            if redis_password is None:
                Log.info(self.__class__.__name__, '__init__',
                         redis_host, redis_port)

                self._redis_conn = redis.StrictRedis(host=redis_host,
                                                     port=redis_port,
                                                     socket_connect_timeout=2)
            else:
                Log.info(self.__class__.__name__, '__init__',
                         redis_host, redis_port, redis_password)

                self._redis_conn = redis.StrictRedis(host=redis_host,
                                                     port=redis_port,
                                                     password=redis_password,
                                                     socket_connect_timeout=2)

        except Exception as e:
            Log.exception(self.__class__.__name__, '__init__',
                          type(e).__name__, traceback.format_exc())

    def has_key(self, key):
        result = False
        if key is None:
            return result

        try:
            if self._redis_conn is not None:
                result = self._redis_conn.get(key) is not None
        except Exception as e:
            Log.exception(self.__class__.__name__, 'has_key',
                          type(e).__name__, traceback.format_exc(),
                              'Exception caught while checking for key', key)

        return result

    def get(self, key):
        if key is None:
            return None

        #Log.cache_call(key)

        result = None
        try:
            if self._redis_conn is not None:
                result = self._redis_conn.get(key)
        except Exception as e:
            Log.exception(self.__class__.__name__, 'get',
                          type(e).__name__, traceback.format_exc(),
                              'Exception caught while getting key', key)

        return result

    def get_json(self, key):
        if key is None:
            return None

        #Log.cache_call(key)

        result = None
        try:
            if self._redis_conn is not None:
                value = self._redis_conn.get(key)
                result = ast.literal_eval(value) if value is not None else value
        except Exception as e:
            Log.exception(self.__class__.__name__, 'get_json',
                          type(e).__name__, traceback.format_exc(),
                              'Exception caught while getting key', key)

        return result

    def set(self, key, value,ttl=0):
        if key is None or value is None:
            raise InvalidArgumentException('Invalid argument passed, key or value is none')

        #Log.cache_call(key,value)

        try:
            if self._redis_conn is not None:
                if ttl > 0:
                    self._redis_conn.setex(key, ttl, value)
                else:
                    self._redis_conn.set(key, value)
        except Exception as e:
            Log.exception(self.__class__.__name__, 'set',
                          type(e).__name__, traceback.format_exc(),
                              'Exception caught while setting key', key)

    def delete(self,key):
        if key is None:
            raise InvalidArgumentException('Invalid argument passed, key is none')

        try:
            if self._redis_conn is not None:
                if type(key) in [str,unicode] and len(key.strip()) > 0:
                    try:
                        self._redis_conn.delete(key)
                    except Exception as e:
                        Log.exception(self.__class__.__name__, 'delete',
                                      type(e).__name__, traceback.format_exc(),
                                          'Exception caught while removing key', key)
                else:
                    Log.error(self.__class__.__name__, 'delete',
                                  'Invalid key type passed or key is empty, key type is', type(key))

        except Exception as e:
            Log.exception(self.__class__.__name__, 'delete',
                          type(e).__name__, traceback.format_exc(), )

class Cache:
    def __init__(self):
        self._impl = CacheFactory.get_impl()

    def get(self, key):
        return self._impl.get(key)

    def get_json(self, key):
        return self._impl.get_json(key)

    def set(self, key, value,ttl=0):
        self._impl.set(key, value)

    def has_key(self, key):
        return self._impl.has_key(key)

    def delete(self, key):
        self._impl.delete(key)

cache_impl = RedisCache()

class CacheFactory:

    @staticmethod
    def get_impl():
        return cache_impl

# if __name__ == '__main__':
#     cache = CacheFactory.get_impl()
#
#     import common.utils as Utils
#
#
#     def data_bin():
#         import random
#         data = {'Id': random.randint(10, 10000),
#                 'Value': Utils.get_uid_hex()}
#         return data
#
#
#     key = Utils.get_uid_hex()
#     cached_data = cache.get(key)
#
#     found = cached_data is not None
#
#     if not found:
#         cache.set(key, data_bin())
#         cached_data = cache.get(key)
#


