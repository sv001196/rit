import json

class RequestUtils:

    @staticmethod
    def isGetRequest(request):
        return True if request.method == 'GET' else False

    @staticmethod
    def isPostRequest(request):
        return True if request.method == 'POST' else False

    @staticmethod
    def getNormalizationFields(request):
        result = dict()
        if RequestUtils.isPostRequest(request):
            result = json.loads(request.body)

        return result

class NormalizationValidationResponse:

    SUCCESS = 1
    FAILURE = 0

    STATUS = 'Status'
    MESSAGE = 'Message'

    UNKNOWN_ERROR = 'UnknownError'

    def __init__(self):
        self.status = NormalizationValidationResponse.FAILURE
        self.message = NormalizationValidationResponse.UNKNOWN_ERROR

    def toJson(self):
        response = {NormalizationValidationResponse.STATUS: self.status,
                    NormalizationValidationResponse.MESSAGE: self.message}
        return response

class NormalizationHttpResponse:

    SUCCESS = 1
    FAILURE = 0

    UNKNOWN_ERROR = 'UnknownError'

    STATUS = 'Status'
    MESSAGE = 'Message'
    DATA = 'Data'


    def __init__(self):
        self.status = NormalizationHttpResponse.FAILURE
        self.message = NormalizationValidationResponse.UNKNOWN_ERROR
        self.data = dict()

    def toJson(self):
        response = {NormalizationHttpResponse.STATUS:self.status,
                    NormalizationHttpResponse.MESSAGE:self.message,
                    NormalizationHttpResponse.DATA:self.data}

        return response
