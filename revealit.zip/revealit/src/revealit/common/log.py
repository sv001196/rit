import datetime
import traceback
from common.env_config import EnvConfig


class Log:
    LOG_ENABLED = '1'

    LOG_LEVEL_INFO = 'LOG_LEVEL_INFO'
    LOG_LEVEL_WARNING = 'LOG_LEVEL_WARNING'
    LOG_LEVEL_ERROR = 'LOG_LEVEL_ERROR'
    LOG_LEVEL_EXCEPTION = 'LOG_LEVEL_EXCEPTION'
    LOG_LEVEL_DB_CALL = 'LOG_LEVEL_DB_CALL'
    LOG_LEVEL_CACHE_CALL = 'LOG_LEVEL_CACHE_CALL'

    @staticmethod
    def info(module_name='',
             method_name='',
             *messages):
        log_level = EnvConfig.get_log_level(Log.LOG_LEVEL_INFO)
        if log_level is None or log_level != Log.LOG_ENABLED:
            return

        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')

            pattern = '{0} |{1}| |{2}.{3}| |{4}|'.format(current_time, 'INFO', module_name, method_name, ', '.join(
                str(message) for message in messages if len(messages) > 0))
            print pattern
        except Exception, e:
            print('Exception caught in Log::info', e)

    @staticmethod
    def enter(module_name='',
              method_name='',
              *messages):

        log_level = EnvConfig.get_log_level(Log.LOG_LEVEL_INFO)
        if log_level is None or log_level != Log.LOG_ENABLED:
            return

        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')
            pattern = '{0} |{1}| |{2}.{3}| {4}'.format(current_time, 'ENTER', module_name, method_name,
                                                       ', '.join(
                                                           str(message) for message in messages if len(messages) > 0))
            print pattern
        except:
            print('Exception caught in Log::enter', traceback.format_exc())
        finally:
            pass

    @staticmethod
    def exit(module_name='',
             method_name='',
             *messages):
        log_level = EnvConfig.get_log_level(Log.LOG_LEVEL_INFO)
        if log_level is None or log_level != Log.LOG_ENABLED:
            return

        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')
            pattern = '{0} |{1}| |{2}.{3}| {4}'.format(current_time, 'EXIT', module_name, method_name,
                                                       ', '.join(
                                                           str(message) for message in messages if len(messages) > 0))
            print pattern
        except:
            print('Exception caught in Log::exit', traceback.format_exc())
        finally:
            pass

    @staticmethod
    def exception(module_name='',
                  method_name='',
                  exception_type='',
                  exception_stack_trace='',
                  *messages):
        log_level = EnvConfig.get_log_level(Log.LOG_LEVEL_EXCEPTION)
        if log_level is None or log_level != Log.LOG_ENABLED:
            return

        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')
            pattern = '{0} |{1}| |{2}.{3}| |{4}| |{5}| |{6}|'.format(current_time, 'EXCEPTION', module_name,
                                                                     method_name, exception_type, exception_stack_trace,
                                                                     ', '.join(str(message) for message in messages if
                                                                               len(messages) > 0))
            print pattern
        except:
            print('Exception caught in Log::exception', traceback.format_exc())
        finally:
            pass

    @staticmethod
    def error(module_name='',
              method_name='',
              error_type='',
              error_details='',
              *messages):
        log_level = EnvConfig.get_log_level(Log.LOG_LEVEL_ERROR)
        if log_level is None or log_level != Log.LOG_ENABLED:
            return

        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')
            pattern = '{0} |{1}| |{2}.{3}| |{4}| |{5}| |{6}|'.format(current_time, 'ERROR', module_name, method_name,
                                                                     error_type, error_details,
                                                                     ', '.join(str(message) for message in messages if
                                                                               len(messages) > 0))
            print pattern
        except:
            print('Exception caught in Log::error', traceback.format_exc())
        finally:
            pass

    @staticmethod
    def warning(module_name='',
                method_name='',
                warning_type='',
                warning_details='',
                *messages):
        log_level = EnvConfig.get_log_level(Log.LOG_LEVEL_WARNING)
        if log_level is None or log_level != Log.LOG_ENABLED:
            return

        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')
            pattern = '{0} |{1}| |{2}.{3}| |{4}| |{5}| |{6}|'.format(current_time, 'WARNING', module_name, method_name,
                                                                     warning_type, warning_details,
                                                                     ', '.join(str(message) for message in messages if
                                                                               len(messages) > 0))
            print pattern
        except:
            print('Exception caught in Log::warning', traceback.format_exc())
        finally:
            pass

    @staticmethod
    def db_call(module_name='',
                method_name='',
                db_name='',
                collection_name='',
                *messages):
        log_level = EnvConfig.get_log_level(Log.LOG_LEVEL_DB_CALL)
        if log_level is None or log_level != Log.LOG_ENABLED:
            return

        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')
            pattern = '{0} |{1}| |{2}.{3}| |{4}| |{5}| |{6}|'.format(current_time, 'DB', module_name, method_name,
                                                                     db_name, collection_name,
                                                                     ', '.join(str(message) for message in messages if
                                                                               len(messages) > 0))
            print pattern
        except:
            print('Exception caught in Log::db_call', traceback.format_exc())
        finally:
            pass

    @staticmethod
    def cache_call(module_name='',
                   method_name='',
                   cache_key='',
                   cache_hit='1',
                   *messages):
        log_level = EnvConfig.get_log_level(Log.LOG_LEVEL_CACHE_CALL)
        if log_level is None or log_level != Log.LOG_ENABLED:
            return

        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')
            pattern = '{0} |{1}| |{2}.{3}| |{4}| |{5}|'.format(current_time, 'CACHE', module_name, method_name,
                                                               cache_key,
                                                               ', '.join(str(message) for message in messages if
                                                                         len(messages) > 0))
            print pattern
        except:
            print('Exception caught in Log::cache_call', traceback.format_exc())
        finally:
            pass

    @staticmethod
    def log_time(module_name='',
                 method_name='',
                 operation_type='',
                 time_taken=0,
                 *messages):
        try:
            current_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S%z')
            pattern = '{0} |{1}| |{2}.{3}| |{4}| |{5}| |{6}|'.format(current_time, 'TIME', module_name, method_name,
                                                                     operation_type, time_taken,
                                                                     ', '.join(str(message) for message in messages if
                                                                               len(messages) > 0))
            print pattern
        except:
            print('Exception caught in Log::log_time', traceback.format_exc())
        finally:
            pass

# if __name__ == '__main__':
#     #     Log.info('api_handler_lambda', 'WebVisitEventHandler', '9598ccc0-14a8-45cf-9136-dfdefcf8b05e', 'Foo', None)
#
#     aws_metadata_url = EnvConfig.get_aws_instance_metadata_url()
#
#     if not aws_metadata_url.endswith('/'):
#         aws_metadata_url += '/'
#     aws_metadata_url += 'instance-id'
#
#     import requests
#     print requests.get(aws_metadata_url).text
