import requests

BASE_URL = 'http://localhost:8888/'

def test_post(normalization_fields):
    URL = BASE_URL + 'normalizer' + '/'
    response = requests.post(URL,json=normalization_fields)
    return response

normalization_fields = {"DataSource":"Windows-Add-Remove",
 "OS":"Windows",
 "Publisher":"Adobe Systems Incorporated",
 "SWTitle":"Adobe Acrobat Reader DC",
 "Version":"18.011.20055",
 "Language":"en"}

response = test_post(normalization_fields)
print 'response for normalizing', normalization_fields, response.status_code, response.text

normalization_fields = {"DataSource":"PackageManager",
 "OS":"Ubuntu",
 "Publisher":"GNU",
 "SWTitle":"Emacs",
 "Version":"34.111.1",
 "Language":"en"}

response = test_post(normalization_fields)
print 'response for normalizing', normalization_fields, response.status_code, response.text