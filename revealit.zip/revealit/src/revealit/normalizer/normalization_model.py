from normalizer.normalization_model_factory import NormalizationModelFactory
from common.log import Log

class NormalizationModel:
    def __init__(self):
        self._model_impl = NormalizationModelFactory.getNormalizationModelInstance()

    def getNormalizedRecord(self, normalization_key):
        METHOD_NAME = 'normalization_key'
        Log.enter(self.__class__.__name__, METHOD_NAME, normalization_key)

        response_json = self._model_impl.getNormalizedRecord(normalization_key)

        Log.exit(self.__class__.__name__, METHOD_NAME, normalization_key, response_json)
        return response_json

    def setNormalizedRecord(self, normalization_key, record):
        METHOD_NAME = 'setNormalizedRecord'
        Log.enter(self.__class__.__name__, METHOD_NAME, normalization_key, record)

        self._model_impl.setNormalizedRecord(normalization_key, record)

        Log.exit(self.__class__.__name__, METHOD_NAME, normalization_key, record)
