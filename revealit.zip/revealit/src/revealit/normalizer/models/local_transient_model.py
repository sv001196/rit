from common.log import Log
from common.cache import CacheFactory, Cache
from common.exceptions import InvalidInputException

class NormalizationTransientModel:
    '''
    This class is an abstraction over cache, it does not persist the
    keys in to a database
    '''
    def __init__(self):
        self._cache = CacheFactory.get_impl()

    def getNormalizedRecord(self, normalization_key):

        METHOD_NAME = 'getNormalizedRecord'
        Log.enter(self.__class__.__name__, METHOD_NAME, normalization_key)

        #response_json = {'Data':normalization_key,'Normalization':normalization_key}
        cache_entry = self._cache.get(normalization_key)
        if cache_entry is not None:
            response_json = cache_entry

        response_json = None

        Log.exit(self.__class__.__name__, METHOD_NAME, normalization_key, response_json)
        return response_json

    def setNormalizedRecord(self, normalization_key, record):

        METHOD_NAME = 'setNormalizedRecord'
        Log.enter(self.__class__.__name__, METHOD_NAME, normalization_key, record)

        if normalization_key is None or record is None or len(normalization_key.strip()) == 0:
            raise InvalidInputException('Cache key or value is invalid')

        self._cache.set(normalization_key, record)

        Log.exit(self.__class__.__name__, METHOD_NAME, normalization_key, record)