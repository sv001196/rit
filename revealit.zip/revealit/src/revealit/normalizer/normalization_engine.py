class NormalizationEngine:

    @staticmethod
    def normalize(key, value):
        return value
