from normalizer.models.local_transient_model import NormalizationTransientModel
from common.log import Log

class NormalizationModelFactory:

    CURRENT_MODULE_NAME = 'NormalizationModelFactory'

    @staticmethod
    def getNormalizationModelInstance():
        METHOD_NAME = 'getNormalizationModelInstance'
        Log.enter(NormalizationModelFactory.CURRENT_MODULE_NAME, METHOD_NAME)

        #model_instance = NormalizationMongoModel()
        model_instance = NormalizationTransientModel()

        Log.exit(NormalizationModelFactory.CURRENT_MODULE_NAME, METHOD_NAME)
        return model_instance
