from common.log import Log
from common.request_utils import RequestUtils, NormalizationValidationResponse, NormalizationHttpResponse

MODULE_NAME = 'normalization_request_validator'

dthandler = lambda obj: obj.isoformat() if isinstance(obj,datetime) else None

class NormalizationRequestValidator:

    CURRENT_MODULE_NAME = 'NormalizationRequestValidator'

    @staticmethod
    def validatePostRequest(request):
        METHOD_NAME = 'validatePostRequest'

        Log.enter(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME)

        if request is None:
            response = NormalizationValidationResponse()
            response.message = 'Invalid request object'

            Log.exit(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME, response.toJson())
            return response

        normalization_json = request.body
        Log.info(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME, 'normalization_json', normalization_json)
        if normalization_json is None or len(normalization_json) == 0:
            response = NormalizationValidationResponse()
            response.message = 'No valid fields to be normalized'

            Log.exit(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME, response.toJson())
            return response

        response = NormalizationValidationResponse()
        response.status = NormalizationValidationResponse.SUCCESS
        response.message = 'Validation success'

        Log.exit(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME)
        return response

    @staticmethod
    def validateGetRequest(request):
        METHOD_NAME = 'validateGetRequest'

        Log.enter(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME)

        if request is None:
            response = NormalizationValidationResponse()
            response.message = 'Invalid request object'

            Log.exit(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME, response.toJson())
            return response

        '''
        normalization_parameter = request.GET.get(RequestConstants.GET_PARAM_FG, None)
        if normalization_parameter is None or len(normalization_parameter.strip()) == 0:
            response = NormalizationValidationResponse()
            response.message = 'Invalid normalizer parameter'

            Log.exit(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME, response.toJson())
            return response
        '''

        response = NormalizationValidationResponse()
        response.status = NormalizationValidationResponse.SUCCESS
        response.message = 'Validation success'

        Log.exit(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME)
        return response

    @staticmethod
    def validateRequest(request):
        METHOD_NAME = 'validateRequest'

        Log.enter(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME)

        if RequestUtils.isGetRequest(request):
            return NormalizationRequestValidator.validateGetRequest(request)

        if RequestUtils.isPostRequest(request):
            return NormalizationRequestValidator.validatePostRequest(request)

        response = NormalizationValidationResponse()
        response.message = 'Unsupported Http Request'

        Log.exit(NormalizationRequestValidator.CURRENT_MODULE_NAME, METHOD_NAME)

        return response