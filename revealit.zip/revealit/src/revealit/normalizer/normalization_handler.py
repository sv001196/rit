#import django

from django.http import HttpResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
import json
from common.log import Log
from common.request_utils import RequestUtils, NormalizationValidationResponse, NormalizationHttpResponse
from normalizer.normalization_model import NormalizationModel
#from normalizer.models.mongo_model import NormalizationMongoModel
#from common.exceptions import InvalidInputException
from normalizer.normalization_request_validator import NormalizationRequestValidator
from normalizer.normalization_engine import NormalizationEngine


MODULE_NAME = 'normalization_handler'

dthandler = lambda obj: obj.isoformat() if isinstance(obj,datetime) else None

# class RequestConstants:
#     GET_PARAM_FG = 'fg'



class NormalizationHandler:

    def __init__(self, request):
        self._request = request
        self._model = NormalizationModel()

    def execute(self):
        METHOD_NAME = 'execute'

        Log.enter(MODULE_NAME, METHOD_NAME)

        response = NormalizationHttpResponse()

        #normalization_key = self._request.GET.get(RequestConstants.GET_PARAM_FG, '')
        normalization_fields = RequestUtils.getNormalizationFields(self._request)

        normalized_result = dict()
        for key, value in normalization_fields.iteritems():
            normalized_value = self._model.getNormalizedRecord(key)

            if normalized_value is None:
                normalized_value = NormalizationEngine.normalize(key, value)
                self._model.setNormalizedRecord(key, normalized_value)

            normalized_result[key] = normalized_value


        response.data = normalized_result
        response.status = NormalizationHttpResponse.SUCCESS
        response.message = 'ExecutionSuccess'

        Log.exit(MODULE_NAME, METHOD_NAME)

        return response

    @staticmethod
    def handleRequest(request):
        METHOD_NAME = 'handleRequest'

        Log.enter(MODULE_NAME, METHOD_NAME)

        normalization_validation_response = NormalizationRequestValidator.validateRequest(request)

        Log.info(MODULE_NAME, METHOD_NAME, 'validation response is', normalization_validation_response.toJson())

        if NormalizationValidationResponse.SUCCESS != normalization_validation_response.status:
            return normalization_validation_response


        #validation is fine, go ahead and execute the business logic
        execution_response = NormalizationHandler(request).execute()
        Log.info(MODULE_NAME, METHOD_NAME, 'execution response is', execution_response)
        Log.exit(MODULE_NAME, METHOD_NAME)
        return execution_response

@csrf_exempt
def handle_normalization(request):
    METHOD_NAME = 'handle_normalization'

    Log.enter(MODULE_NAME, METHOD_NAME)
    response = NormalizationHandler.handleRequest(request)
    Log.exit(MODULE_NAME, METHOD_NAME, response.status)

    if NormalizationHttpResponse.SUCCESS == response.status:
        return HttpResponse(json.dumps(response.toJson()))
    else:
        return HttpResponseBadRequest(json.dumps(response.toJson()))